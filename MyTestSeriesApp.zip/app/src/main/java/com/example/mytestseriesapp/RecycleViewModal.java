package com.example.mytestseriesapp;

public class RecycleViewModal {
    String index;
    String data;

    public RecycleViewModal(String index, String data) {
        this.index = index;
        this.data = data;
    }

}
